package httpclient.bean;

public class Attribute {

    private SimpleFlow flow;

    public SimpleFlow getFlow() {
        return flow;
    }

    public void setFlow(SimpleFlow flow) {
        this.flow = flow;
    }
}
