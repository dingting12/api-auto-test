package httpclient.bean;

public class Field {

    private String column;
    private String type;
    private Boolean valid = true;

    public String getColumn() {
        return column;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getValid() {
        return valid;
    }

    public void setValid(Boolean valid) {
        this.valid = valid;
    }


    public Field(){
        this.column = column;
        this.type = type;
        this.valid = valid;
    }
    public Field(String column, String type, Boolean valid) {
        this.column = column;
        this.type = type;
        this.valid = valid;
    }
}
