package httpclient.bean;

public class Link {
    private String source;
    private String target;
    private String targetInput;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getTargetInput() {
        return targetInput;
    }

    public void setTargetInput(String targetInput) {
        this.targetInput = targetInput;
    }



}
