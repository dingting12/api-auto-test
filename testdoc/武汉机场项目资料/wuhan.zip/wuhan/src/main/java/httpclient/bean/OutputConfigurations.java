package httpclient.bean;

import java.util.List;

public class OutputConfigurations {
    private List<TableN> outputConfigurations;
}
