package httpclient.bean;

import java.util.List;

public class Parameter {
    private String category;
    private String defaultVal;
    private String description;
    private String name;
    private List<String> refs;

    public Parameter() {
    }

    public Parameter(String category, String defaultVal, String description, String name, List<String> refs) {
        this.category = category;
        this.defaultVal = defaultVal;
        this.description = description;
        this.name = name;
        this.refs = refs;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDefaultVal() {
        return defaultVal;
    }

    public void setDefaultVal(String defaultVal) {
        this.defaultVal = defaultVal;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getRefs() {
        return refs;
    }

    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
}
