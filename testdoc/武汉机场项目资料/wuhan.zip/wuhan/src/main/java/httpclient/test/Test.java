package httpclient.test;

import httpclient.HttpDemo;
import httpclient.bean.TableInfo;
import org.apache.commons.collections4.map.MultiValueMap;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.*;

public class Test {
    public static Logger logger = LoggerFactory.getLogger(Test.class);
    public static void main(String[] args) throws Exception{
        ResourceBundle resourceBundle = ResourceBundle.getBundle("config");
        String excelPath = new String(resourceBundle.getString("excelPath").getBytes("iso-8859-1"), "gbk");
        System.out.println(excelPath);

        //excel文件路径
//        String excelPath = "C:\\Users\\Juyun4\\Desktop\\wuhan\\数仓表表加载规则梳理(5).xlsx";
        List<String> tableList = new ArrayList<String>();
        tableList.add("ACMS_FLIGHT_WUH");
        tableList.add("ACMS_FLIGHT_DIFU");
        tableList.add("FIN_LSBMZD_VER");
        tableList.add("AAAA");
        Map<String, List<TableInfo> >  map = getKey(excelPath, tableList);

//        Map<String, String > map = getKey(excelPath, tableList);

        for (Map.Entry<String, List<TableInfo>> entry : map.entrySet()) {
            List<TableInfo> list = entry.getValue();
            for(int i = 0; i < list.size(); i++){
                System.out.println(entry.getKey() + list.get(i).getiType());
                String field = list.get(i).getField();
                if(!"".equals(field) && !"-".equals(field)){
                    String condition = field + "=" + "DATE_SUB(CURRENT_DATE,1)";
                    System.out.println(condition);
                }

            }

        }

    }

    public static Map<String, List<TableInfo> > getKey(String excelPath, List<String> tableList){
        Map<String,List<TableInfo>> map = new HashMap<String, List<TableInfo>>(); //存每行数据
        try {
            File file = new File(excelPath);
            if(file.exists()&&file.isFile()){

                FileInputStream fs = new FileInputStream(file);
                Workbook wb = new XSSFWorkbook(fs);
                fs.close();
                for(int index = 0; index < 3; index++){
                    Sheet sheet = wb.getSheetAt(index);
                    int firstRowIndex = sheet.getFirstRowNum()+1;   //第一行是列名，所以不读
                    int lastRowIndex = sheet.getLastRowNum();
                    for(int rIndex = firstRowIndex; rIndex <= lastRowIndex; rIndex ++){
                        Row row = sheet.getRow(rIndex);
                        if(row != null){
                            int firstCellIndex = row.getFirstCellNum();
                            int lastCellIndex = row.getLastCellNum();
                            String topic = row.getCell(0).toString();
                            String schema = row.getCell(1).toString();
                            String table = row.getCell(2).toString();
                            String cName = row.getCell(3).toString();
                            String iType = row.getCell(4).toString();
                            String period = row.getCell(5).toString();
                            String field = row.getCell(6).toString();
                            if(index == 2){
                                field = row.getCell(7).toString();
                            }
                            String rule = row.getCell(7).toString();
                            if(index == 0){
                                rule = row.getCell(8).toString();
                            }else if(index == 2){
                                rule = row.getCell(9).toString();
                            }
                            TableInfo tableInfo = new TableInfo(topic, schema, table, iType, period, field, rule,cName);
                            String key = topic;
//                        cell4.setCellType(1);

//                        if(tableList.contains(table)){
//                            if(map.get(key) != null){
//                                map.put(key, map.get(key) + "," + table);
//                            }else{
//                                map.put(key, table);
//                            }
//                        }
                            if(!"".equals(topic)){
                                if(map.get(key) != null){
                                    List<TableInfo> list= new ArrayList<TableInfo>();
                                    list.addAll(map.get(key));
                                    list.add(tableInfo);
                                    map.put(key,list);
                                }else{
                                    List<TableInfo> list= new ArrayList<TableInfo>();
                                    list.add(tableInfo);
                                    map.put(key,list);
                                }
                            }

                        }
                    }

                }




            }else{
                System.out.println("找不到指定的文件。");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }

}
