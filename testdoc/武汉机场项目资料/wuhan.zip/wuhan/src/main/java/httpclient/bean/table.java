package httpclient.bean;

import java.util.List;

public class table {
    private List<Field> Fields;
    private String id;

    public List<Field> getFields() {
        return Fields;
    }

    public void setFields(List<Field> Fields) {
        this.Fields = Fields;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }



}
