package httpclient.bean;

import java.util.List;

public class Step {

    private String id;
    private String name;
    private OtherConfigurations otherConfigurations;
    private List<TableN> outputConfigurations;
    private List<InputConfiguration> inputConfigurations;
    private String type;
    private Integer x;
    private Integer y;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public OtherConfigurations getOtherConfigurations() {
        return otherConfigurations;
    }

    public void setOtherConfigurations(OtherConfigurations otherConfigurations) {
        this.otherConfigurations = otherConfigurations;
    }

    public List<TableN> getOutputConfigurations() {
        return outputConfigurations;
    }

    public void setOutputConfigurations(List<TableN> outputConfigurations) {
        this.outputConfigurations = outputConfigurations;
    }

    public List<InputConfiguration> getInputConfigurations() {
        return inputConfigurations;
    }

    public void setInputConfigurations(List<InputConfiguration> inputConfigurations) {
        this.inputConfigurations = inputConfigurations;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }
}
