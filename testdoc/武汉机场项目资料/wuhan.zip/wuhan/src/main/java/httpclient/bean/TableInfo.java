package httpclient.bean;

public class TableInfo {
    private String topic;
    private String schema;
    private String table;
    private String iType;
    private String period;
    private String field;
    private String rule;
    private String cName;

    public TableInfo(String topic, String schema, String table, String iType, String period, String field, String rule, String cName) {
        this.topic = topic;
        this.schema = schema;
        this.table = table;
        this.iType = iType;
        this.period = period;
        this.field = field;
        this.rule = rule;
        this.cName = cName;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getSchema() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public String getiType() {
        return iType;
    }

    public void setiType(String iType) {
        this.iType = iType;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getRule() {
        return rule;
    }

    public void setRule(String rule) {
        this.rule = rule;
    }
}
