package httpclient.bean;

import java.util.List;

public class AccessTables {
    Long total;
    Long totalPages;
    Boolean first;
    Boolean last;


    class FacetContent{
        public String getFacet() {
            return facet;
        }

        public void setFacet(String facet) {
            this.facet = facet;
        }

        public Long getCount() {
            return count;
        }

        public void setCount(Long count) {
            this.count = count;
        }

        public String getField() {
            return field;
        }

        public void setField(String field) {
            this.field = field;
        }

        String facet;
        Long count;
        String field;
    }

    class Content{
        String name;
        String creator;
        Long createTime;
        String lastModifier;
        Long lastModifiedTime;
        String owner;
        Long version;
        Long moduleVersion;
        Long enabled;
        String solrdocVersion;
        Boolean nameDuplicatable;
        Long storageEngine;
        Boolean quoted;
        Long databaseID;
        Long rowNumber;
        Long byteSize;
        Long analysisTime;
        Long tableType;
        Long modelType;

    }

}
