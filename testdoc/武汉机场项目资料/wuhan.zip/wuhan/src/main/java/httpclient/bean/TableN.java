package httpclient.bean;

import java.util.List;

public class TableN {
    private List<Field> fields;
    private String id;

    public List<Field> getFields() {
        return fields;
    }

    public void setFields(List<Field> fields) {
        this.fields = fields;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


}
