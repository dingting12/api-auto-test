package httpclient;

import com.google.gson.*;
import httpclient.bean.*;
import org.apache.http.Header;
import org.apache.http.client.methods.CloseableHttpResponse;

import java.io.*;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HttpDemo {
    public static Logger logger = LoggerFactory.getLogger(HttpDemo.class);

    public static String login(String url, String params){
        return HttpClientUtil.sendHttpPost(
                  url,params);
    }

    public static String getTables(String url){
        return HttpClientUtil.sendHttpGet(url);
    }

    public static String exists(String url){
        return HttpClientUtil.sendHttpGet(url);
    }

    public static String createPath(String url, String json){
        return HttpClientUtil.sendHttpPostJson(url, json);
    }

    public static String getTableFields(String table, String getFieldsUrl){

        String url = null;
        try {
            url = getFieldsUrl + URLEncoder.encode(table,"utf-8");
//            System.out.println(url);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return HttpClientUtil.sendHttpGet(url);
//        return null;
    }

    public static String dataflowPost(String url, String json){
        return HttpClientUtil.sendHttpPostJson(url, json);

    }

    public static String getParentId(String url){
        String str =  HttpClientUtil.sendHttpGet(url);
        JsonParser parser = new JsonParser();
        JsonObject object = (JsonObject)parser.parse(str);
        String id = object.get("id").getAsString();
        return id;
    }

    public static void main(String[] args) throws Exception{

        ResourceBundle resourceBundle = ResourceBundle.getBundle("config");
        String excelPath = new String(resourceBundle.getString("excelPath").getBytes("iso-8859-1"), "gbk");
        String prefix = resourceBundle.getString("prefix");
        String sourceSchema = resourceBundle.getString("sourceSchema");
        String sinkSchema = resourceBundle.getString("sinkSchema");
        String loginUrl = prefix + "/api/zebra/auth/login";
        String loginParams = resourceBundle.getString("loginParams");
        String accessTablesUrl = prefix + "/api/zebra/client/query/table?filter=" +
                sourceSchema + "&offset=0&query=&sorts=+TABLE_NAME";
        String getFieldsUrl = prefix + "/api/zebra/schema/obj/table/editget?schemaName=" + sourceSchema + "&table=";
        String dfTree = new String(resourceBundle.getString("dfTree").getBytes("iso-8859-1"), "gbk");
        String basePath = new String(resourceBundle.getString("basePath").getBytes("iso-8859-1"), "gbk");
        String mkdirUrl = prefix + "/api/zebra/tree/mkdir";
        String errorFile = resourceBundle.getString("errorFile");
        String token = login(loginUrl, loginParams);
        HttpClientUtil.setToken(token);
//        System.out.println( HttpClientUtil.getToken());
        //获取所有表名
//        String accessTables = getTables(accessTablesUrl);

        //获取数据流程父目录
        String topicUrl = null;
        String dbUrl = null;
        String dataflowUrl = null;



        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        //table列
//        List<String> tableList = getTableNames(accessTables);
        Map<String,List<TableInfo>> tMap = getMap(excelPath);

        Map<String,String> fails = new HashMap<String, String>();

        //遍历每个主题的value
        for(Map.Entry<String, List<TableInfo>> entry : tMap.entrySet()){
            StringBuilder stringBuilder=new StringBuilder();
            int failure = 0;
            int success = 0;
            List<String> flowIds = new ArrayList<String>();//存储增量dataflow id
            List<String> flowIds2 = new ArrayList<String>();//存储全量dataflow id

            List<DataFlow> dfs1 = new ArrayList<DataFlow>();//存储增量dataflow
            List<DataFlow> dfs2 = new ArrayList<DataFlow>();//存储全量dataflow

            List<TableInfo> infoList = entry.getValue();
            topicUrl = prefix + "/api/zebra/tree/status?path=" +
                    URLEncoder.encode(basePath + entry.getKey(),"utf-8");
//            System.out.println("topicUrl = " + topicUrl);
            if(exists(topicUrl) == null){
                Dir dir = new Dir();
                dir.setPath(basePath + entry.getKey());
//                System.out.println(gson.toJson(dir));
                createPath(mkdirUrl, gson.toJson(dir));
            }
            String parentId = getParentId(topicUrl);
            //遍历每个value的信息
            for(int i = 0; i < infoList.size(); i++){
                TableInfo tableInfo = infoList.get(i);
                String table = tableInfo.getTable();
                getFieldsUrl = prefix + "/api/zebra/schema/obj/table/editget?schemaName=" + tableInfo.getSchema() + "&table=";
                String t = getTableFields(table, getFieldsUrl);
                if(t == null){
                    stringBuilder.append(table).append(",");
                    failure ++;
                    continue;
                }
                List<Field> fieldList = JsonToField(t);
                String tableName = table;
                String mode = tableInfo.getiType(); //增量or全量（有无filter）
                String rule = tableInfo.getRule();  //默认抽取N天前的数据
                String condition = "";
                if(!"".equals(tableInfo.getField()) && "增量".equals(mode)){
//                    condition = tableInfo.getField() + "=" + "DATE_SUB(CURRENT_DATE,1)";
//                    condition = "#{begin:'20190629'} <= DATE_FORMAT(" +
//                            tableInfo.getField() +  ",'yyyyMMdd')" + " and DATE_FORMAT(" + tableInfo.getField() + ",'yyyyMMdd') < #{end:'20190629'}";
                    condition = tableInfo.getField() + " >= cast(#{begin:'20190629'} as date) " +
                            "and " + tableInfo.getField() + "< cast(#{end:'20190629'} as date)";
                }




                dbUrl = prefix + "/api/zebra/tree/status?path=" +
                        URLEncoder.encode(basePath + entry.getKey() + "/" + tableInfo.getSchema() + "/","utf-8");
                if(exists(dbUrl) == null){
                    Dir dir = new Dir();
                    dir.setPath(basePath + entry.getKey() + "/" + tableInfo.getSchema() + "/");
                    createPath(mkdirUrl, gson.toJson(dir));
                }

                String dbId = getParentId(dbUrl);

//                System.out.println(mode);
                DataFlow dataFlow = createDataFlow(fieldList, tableInfo.getSchema(), "BG_" + tableInfo.getSchema() , tableName, i, dbId, condition, mode, tableInfo.getcName(), rule); //创建dataflow对象
                dataflowUrl = prefix + "/api/zebra/tree/save?force=&path=" +
                        URLEncoder.encode(basePath + entry.getKey() + "/" + tableInfo.getSchema() + "/","utf-8") + dataFlow.getName();
//                System.out.println(gson.toJson(dataFlow));
                String dataFlowResult = dataflowPost(dataflowUrl, gson.toJson(dataFlow)); //创建dataflow流程
                if(dataFlowResult == null){
                    stringBuilder.append(table).append(",");
                    failure ++;
                    logger.error("dataflow创建出错：sourceTable is {}",tableName);
                }else{
                    JsonParser parser = new JsonParser();
                    JsonObject object = (JsonObject)parser.parse(dataFlowResult);
                    String flowId = object.get("id").getAsString();
                    dataFlow.setId(flowId);
                    success ++;
                    logger.info("dataflow创建成功：sourceTable is {}",tableName);
                    if("增量".equals(mode)){
                        flowIds.add(flowId);
                        dfs1.add(dataFlow);
                    }else{
                        dfs2.add(dataFlow);
                        flowIds2.add(flowId);
                    }

                }
            }
            fails.put(entry.getKey(),stringBuilder.toString());

            //执行创建增量subflow
            String subName = "subflow-" +"增量"+ entry.getKey();
            String subJson = gson.toJson(createSubflow(dfs1,subName, parentId));
            String subflowUrl = prefix + "/api/zebra/tree/save?force=&path=" +
                    URLEncoder.encode(basePath + entry.getKey() + "/" + subName,"utf-8") ;
            dataflowPost(subflowUrl, subJson);

            //执行创建全量subflow
            String subName2 = "subflow-" +"全量"+ entry.getKey();
            String subJson2 = gson.toJson(createSubflow(dfs2,subName2, parentId));
            String subflowUrl2 = prefix + "/api/zebra/tree/save?force=&path=" +
                    URLEncoder.encode(basePath + entry.getKey() + "/"  + subName2,"utf-8");

            dataflowPost(subflowUrl2, subJson2);

        }

        File file =new File(errorFile);
        Writer out =new FileWriter(file);
        for(Map.Entry<String, String> entry : fails.entrySet()){
            out.write(entry.getKey()+ "-"+entry.getValue());
            out.write("\r\n");
        }
        out.close();





//        List<String> flowIds = new ArrayList<String>();
//        for(int i = 0; i < 1; i++){
//            String table = tableList.get(i);
//            String t = getTableFields(table, getFieldsUrl);
//            List<Field> fieldList = JsonToField(t);
//            String tableName = table;
//            String condition = "1=1";
//            String mode = "increment"; //增量or全量（有无filter）
//            DataFlow dataFlow = createDataFlow(fieldList, sourceSchema, sinkSchema, tableName, i, parentId, condition, mode); //创建dataflow对象
//            dataflowUrl = prefix + "/api/zebra/tree/save?force=&path=" +
//                        URLEncoder.encode(dfTree,"utf-8") + dataFlow.getName();
//
//            System.out.println(gson.toJson(dataFlow));
//            String dataFlowResult = dataflowPost(dataflowUrl, gson.toJson(dataFlow)); //创建dataflow流程
//            if(dataFlowResult == null){
//                logger.error("dataflow创建出错：sourceTable is {}",tableName);
//            }else{
//                JsonParser parser = new JsonParser();
//                JsonObject object = (JsonObject)parser.parse(dataFlowResult);
//                String flowId = object.get("id").getAsString();
//                logger.info("dataflow创建成功：sourceTable is {}",tableName);
//                flowIds.add(flowId);
//            }
//        }

//        for(String id: flowIds){
//            System.out.println(id);
//        }
        //执行创建subflow
//        String subName = "subflow-" +
//                new SimpleDateFormat("yyyy-MM-ddHHmmssSSS").format(new Date());
//        String subJson = gson.toJson(createSubflow(flowIds,subName, parentId));
//        String subflowUrl = prefix + "/api/zebra/tree/save?force=&path=" +
//                URLEncoder.encode(dfTree,"utf-8") + subName;
//        dataflowPost(subflowUrl, subJson);

    }



    public static List<String> getTableNames(String accessTables){
        List<String> list = new ArrayList<String>();
        JsonParser parser = new JsonParser();
        JsonObject object = (JsonObject)parser.parse(accessTables);
        JsonArray tables = object.getAsJsonArray("content");
        for(JsonElement jsonElement: tables){
            JsonObject table = jsonElement.getAsJsonObject();
            list.add(table.get("name").getAsString());
        }
        return list;
    }

    public static List<Field> JsonToField(String jsonStr){
        List<Field> list = new ArrayList<Field>();

        JsonParser parser = new JsonParser();
        JsonObject object = (JsonObject)parser.parse(jsonStr);
        JsonArray columnsInfo = object.getAsJsonArray("fields");
        for(JsonElement jsonElement: columnsInfo){
            Field field = new Field();
            JsonObject columnInfo = jsonElement.getAsJsonObject();
            String columnName = columnInfo.get("columnName").getAsString();
            String dataType = columnInfo.get("dataType").getAsString();
            field.setColumn(columnName);
            field.setType(dataType);
            list.add(field);
        }
        return list;
    }

    public static DataFlow createDataFlow(List<Field> fieldList, String sourceSchema, String sinkSchema, String tableName, int index, String parentId, String condition, String mode, String cName, String rule){
        DataFlow dataFlow = new DataFlow();
        Flow flow = createFlow(fieldList, sourceSchema, sinkSchema, tableName, index, condition, mode, cName, rule);
        SimpleFlow sf = new SimpleFlow();
        sf.setName(flow.getName());
        Attribute attribute = new Attribute();
        attribute.setFlow(sf);
        dataFlow.setAttributes(attribute);
        dataFlow.setFlow(flow);
        dataFlow.setParentId(parentId);
        dataFlow.setResType("dataflow");
        dataFlow.setName(flow.getName());
        return dataFlow;
    }

    public static Flow createFlow(List<Field> fieldList, String sourceSchema, String sinkSchema, String tableName, int index, String condition, String mode, String cName, String rule){
        //构造steps
        List<Step> stepList = new ArrayList<Step>();
        stepList.add(createSourceStep(fieldList, sourceSchema, tableName, index));
        if("增量".equals(mode)){//增量模式
            stepList.add(createFilterStep(fieldList,sourceSchema,tableName,index, condition));
        }
        stepList.add(createTransformStep(fieldList,sourceSchema,sinkSchema,index,condition));

        List<Field> fieldList2 = new ArrayList<Field>();
        fieldList2.addAll(fieldList);
        fieldList2.add(new Field("LOADTIME", "DATE", true));
        stepList.add(createSinkStep(fieldList2, sinkSchema, tableName, index, mode));

        Flow flow = new Flow();
        flow.setFlowType("dataflow");
        List<Link> linkList = new ArrayList<Link>();
        if("增量".equals(mode)){
            Link link1 = new Link();
            link1.setSource("source_" + index);
            link1.setTarget("filter_" + index);
            link1.setTargetInput("input");
            linkList.add(link1);
            Link link2 = new Link();
            link2.setSource("filter_" + index);
            link2.setTarget("transform_" + index);
            link2.setTargetInput("input");
            linkList.add(link2);
            Link link3 = new Link();
            link3.setSource("transform_" + index);
            link3.setTarget("sink_" + index);
            link3.setTargetInput("input");
            linkList.add(link3);

            List<Parameter> parameters = new ArrayList<Parameter>();
            Parameter parameter = new Parameter();
            parameter.setName("开始时间");
            parameter.setCategory("var");
            String defaultVal = "1";
            if(!"".equals(rule) && rule != null){
                Double doubleRule = Double.parseDouble(rule);
                defaultVal = "#{getBeforeDate(" + doubleRule.intValue() + ")}";
            }

            parameter.setDefaultVal(defaultVal);
            List<String> refs = new ArrayList<String>();
            refs.add("begin");
            parameter.setRefs(refs);
            parameters.add(parameter);

            Parameter parameter1 = new Parameter();
            parameter1.setName("结束时间");
            parameter1.setCategory("var");
            String defaultVal1 = "1";
            if(!"".equals(rule) && rule != null){
                Double doubleRule1 = Double.parseDouble(rule);
                defaultVal1 = "#{getBeforeDate(" + (doubleRule1.intValue() - 1) + ")}";
            }

            parameter1.setDefaultVal(defaultVal1);
            List<String> refs1 = new ArrayList<String>();
            refs1.add("end");
            parameter1.setRefs(refs1);
            parameters.add(parameter1);

            flow.setParameters(parameters);
        }else{
            Link link1 = new Link();
            link1.setSource("source_" + index);
            link1.setTarget("transform_" + index);
            link1.setTargetInput("input");
            linkList.add(link1);
            Link link2 = new Link();
            link2.setSource("transform_" + index);
            link2.setTarget("sink_" + index);
            link2.setTargetInput("input");
            linkList.add(link2);
        }
        flow.setLinks(linkList);
        String dataflow = cName + "-" + tableName;
        flow.setName(dataflow);
        flow.setSteps(stepList);
        return flow;
    }

    public static Step createSourceStep(List<Field> fieldList, String schema, String tableName, int index){
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        OtherConfigurations oc = new OtherConfigurations();
        oc.setDataset(schema + "." + tableName);
        oc.setiType("spark");
        TableN t = new TableN();
        t.setFields(fieldList);
        t.setId("output");
        List<TableN> tlist = new ArrayList<TableN>();
        tlist.add(t);
        Step step = new Step();
        step.setId("source_" + index);
        step.setName("数据输入_" + index);
        step.setOtherConfigurations(oc);
        step.setOutputConfigurations(tlist);
        step.setType("source");
        step.setX(200);
        step.setY(147);
        return step;
    }



    public static Step createSinkStep(List<Field> fieldList, String schema, String tableName, int index, String mode){
        OtherConfigurations oc = new OtherConfigurations();
        oc.setDataset(schema + "." + tableName);
        oc.setCaseSensitive(false);
        oc.setExpiredTime(0);
        oc.setiType("spark");
        if("增量".equals(mode)){
            oc.setMode("append");
        }else{
            oc.setMode("overwrite");
        }

        oc.setPallas("0");
        oc.setSliceType("H");
        oc.setUpsert(false);
        List<InputConfiguration> inputConfigurations = new ArrayList<InputConfiguration>();
        InputConfiguration ic = new InputConfiguration();
        ic.set$inputFields(fieldList);
        ic.setFields(fieldList);
        ic.setId("input");
        inputConfigurations.add(ic);
        Step step = new Step();
        step.setId("sink_" + index);
        step.setName("数据输出_" + index);
        step.setOtherConfigurations(oc);
        step.setOutputConfigurations(null);
        step.setInputConfigurations(inputConfigurations);
        step.setType("sink");
        step.setX(800);
        step.setY(147);
        return step;
    }

    public static Step createFilterStep(List<Field> fieldList, String schema, String tableName, int index, String condition){
        OtherConfigurations oc = new OtherConfigurations();
        oc.setCondition(condition);
        oc.setiType("spark");

        List<InputConfiguration> inputConfigurations = new ArrayList<InputConfiguration>();
        InputConfiguration ic = new InputConfiguration();
        ic.set$inputFields(fieldList);
        ic.setFields(fieldList);
        ic.setId("input");
        inputConfigurations.add(ic);
        TableN t = new TableN();

        t.setFields(fieldList);
        t.setId("output");
        List<TableN> tlist = new ArrayList<TableN>();
        tlist.add(t);
        Step step = new Step();
        step.setId("filter_" + index);
        step.setName("过滤_" + index);
        step.setOtherConfigurations(oc);
        step.setInputConfigurations(inputConfigurations);
        step.setOutputConfigurations(tlist);
        step.setType("filter");
        step.setX(400);
        step.setY(147);
        return step;
    }

    public static Step createTransformStep(List<Field> fieldList, String schema, String tableName, int index, String condition){
        OtherConfigurations oc = new OtherConfigurations();
        List<String> expressions = new ArrayList<String>();
        expressions.add("to_timestamp(CURRENT_TIMESTAMP) as LOADTIME");
        oc.setExpressions(expressions);
        oc.setiType("spark");

        List<InputConfiguration> inputConfigurations = new ArrayList<InputConfiguration>();
        InputConfiguration ic = new InputConfiguration();
        ic.set$inputFields(fieldList);
        ic.setFields(fieldList);
        ic.setId("input");
        inputConfigurations.add(ic);

        TableN t = new TableN();
        List<Field> fieldList2 = new ArrayList<Field>();
        fieldList2.addAll(fieldList);
        fieldList2.add(new Field("LOADTIME", "DATE", true));
        t.setFields(fieldList2);
        t.setId("output");
        List<TableN> tlist = new ArrayList<TableN>();
        tlist.add(t);

        Step step = new Step();
        step.setId("transform_" + index);
        step.setType("transform");
        step.setName("转换_" + index);
        step.setOutputConfigurations(tlist);
        step.setOtherConfigurations(oc);
        step.setInputConfigurations(inputConfigurations);
        step.setX(600);
        step.setY(147);

        return step;
    }

    //创建subflow steps
    public static List<Step> createSubSteps(List<DataFlow> dfs){
        List<Step> steps = new ArrayList<Step>();
        for(int i = 0; i < dfs.size(); i++){
            OtherConfigurations otherConfigurations = new OtherConfigurations();
            otherConfigurations.setDataflowId$(dfs.get(i).getId());
            otherConfigurations.setiType("spark");
            otherConfigurations.setResType("dataflow");
            otherConfigurations.setType("linkoopsql");
            Step step = new Step();
            step.setOtherConfigurations(otherConfigurations);
            step.setId("subflow_" + i);
            step.setName(dfs.get(i).getName());
            step.setType("subflow");
            step.setX(200 * (i%10 + 1));
            step.setY(200 * (i/10 + 1));
            steps.add(step);
        }
        return steps;
    }

    //创建subflow links
    public static List<Link> createSubLinks(List<DataFlow> dfs){
        List<Link> links = new ArrayList<Link>();
        for(int i = 0; i < dfs.size()-1; i++){
            Link link = new Link();
            link.setSource("subflow_" + i);
            link.setTarget("subflow_" + (i + 1));
            links.add(link);
        }
        return links;
    }

    //创建subflow flow
    public static Flow createSubFlow(List<DataFlow> dfs, String subName){
        Flow flow = new Flow();
        flow.setSteps(createSubSteps(dfs));
        flow.setLinks(createSubLinks(dfs));
        flow.setName(subName);
        flow.setFlowType("workflow");
        List<Parameter> parameters = new ArrayList<Parameter>();
        for(int i = 0; i < dfs.size(); i++){
            List<Parameter> parameters1 = dfs.get(i).getFlow().getParameters();
            if(parameters1 !=null ){
                for(int j = 0; j < parameters1.size(); j++){
                    Parameter parameter = new Parameter();
                    List<String> refs = new ArrayList<String>();
                    refs.add("subflow_"+ i+"."+parameters1.get(j).getName());
                    parameter.setRefs(refs);
                    parameter.setName(parameters1.get(j).getName() + "_" + i);
                    parameter.setDefaultVal(parameters1.get(j).getDefaultVal());
                    parameter.setCategory("ref");
                    parameter.setDescription(parameters1.get(j).getDescription());
                    parameters.add(parameter);
                }
            }

        }
        flow.setParameters(parameters);


        return flow;
    }

    public static DataFlow createSubflow(List<DataFlow> dfs, String subName, String parentId){
        DataFlow dataFlow = new DataFlow();
        SimpleFlow simpleFlow = new SimpleFlow();
        simpleFlow.setName(subName);
        Attribute attribute = new Attribute();
        attribute.setFlow(simpleFlow);
        dataFlow.setAttributes(attribute);
        dataFlow.setName(subName);
        dataFlow.setParentId(parentId);
        dataFlow.setResType("workflow");
        dataFlow.setFlow(createSubFlow(dfs, subName));
        return dataFlow;
    }

    public static Map<String, List<TableInfo> > getMap(String excelPath){
        Map<String,List<TableInfo>> map = new HashMap<String, List<TableInfo>>(); //存每行数据
        try {
            File file = new File(excelPath);
            if(file.exists()&&file.isFile()){

                FileInputStream fs = new FileInputStream(file);
                Workbook wb = new XSSFWorkbook(fs);
                fs.close();
                for(int index = 3; index < 4; index++){
                    Sheet sheet = wb.getSheetAt(index);
                    int firstRowIndex = sheet.getFirstRowNum()+1;   //第一行是列名，所以不读
                    int lastRowIndex = sheet.getLastRowNum();
                    for(int rIndex = firstRowIndex; rIndex <= lastRowIndex; rIndex ++){
                        Row row = sheet.getRow(rIndex);
                        if(row != null){
                            int firstCellIndex = row.getFirstCellNum();
                            int lastCellIndex = row.getLastCellNum();
                            String topic = row.getCell(0).toString();
                            String schema = row.getCell(1).toString();
                            String table = row.getCell(2).toString();
                            String cName = row.getCell(3).toString();
                            String iType = row.getCell(4).toString();
                            String period = row.getCell(5).toString();
                            String field = row.getCell(6).toString();
//                            if(index == 2){
//                                field = row.getCell(7).toString();
//                            }
                            String rule = row.getCell(7).toString();
//                            if(index == 0){
//                                rule = row.getCell(8).toString();
//                            }else if(index == 2){
//                                rule = row.getCell(9).toString();
//                            }
                            TableInfo tableInfo = new TableInfo(topic, schema, table, iType, period, field, rule, cName);
                            String key = topic;
//                        cell4.setCellType(1);

//                        if(tableList.contains(table)){
//                            if(map.get(key) != null){
//                                map.put(key, map.get(key) + "," + table);
//                            }else{
//                                map.put(key, table);
//                            }
//                        }
                            if(!"".equals(topic)){
                                if(map.get(key) != null){
                                    List<TableInfo> list= new ArrayList<TableInfo>();
                                    list.addAll(map.get(key));
                                    list.add(tableInfo);
                                    map.put(key,list);
                                }else{
                                    List<TableInfo> list= new ArrayList<TableInfo>();
                                    list.add(tableInfo);
                                    map.put(key,list);
                                }
                            }

                        }
                    }

                }




            }else{
                System.out.println("找不到指定的文件。");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }


}
