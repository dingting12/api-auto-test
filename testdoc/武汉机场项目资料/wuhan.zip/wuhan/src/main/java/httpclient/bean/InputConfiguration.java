package httpclient.bean;

import java.util.List;

public class InputConfiguration {
    private List<Field> $inputFields;
    private List<Field> fields;
    private String id;

    public List<Field> get$inputFields() {
        return $inputFields;
    }

    public void set$inputFields(List<Field> $inputFields) {
        this.$inputFields = $inputFields;
    }

    public List<Field> getFields() {
        return fields;
    }

    public void setFields(List<Field> fields) {
        this.fields = fields;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


}
